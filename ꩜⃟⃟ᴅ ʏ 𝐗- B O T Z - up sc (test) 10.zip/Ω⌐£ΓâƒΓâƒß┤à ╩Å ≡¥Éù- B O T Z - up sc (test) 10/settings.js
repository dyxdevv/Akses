const fs = require('node:fs');

const config = {
    owner: ["6285198726649"],
    name: "꩜⃟⃟ᴅ ʏ 𝐗- B O T Z",
    ownername: '꩜⃟⃟ᴅ ʏ 𝐗', 
    ownername2: '꩜⃟⃟ᴅ ʏ 𝐗-DEV',
    prefix: [".", "?", "!", "/", "#"], //Tambahin sendiri prefix nya kalo kurang
    wagc: [ "https://chat.whatsapp.com/JyeT1hdCPJeLy95tzxeyI", "https://chat.whatsapp.com/DfffgArbTUu46mE0" ],
    saluran: '120363385599874603@newsletter', 
    jidgroupnotif: '1203632665712733@g.us', 
    saluran2: '120363385599874603@newsletter', 
    jidgroup: '1203632671094949@g.us', 
    wach: 'https://whatsapp.com/channel/0029VaxXr2L7NoZzrJrL5T2o', 
    sessions: "sessions",
    groq: {
     api: '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'
    },
    link: {
     tt: "https://www.tiktok.com/@w.who.i_am/"
    },
    sticker: {
      packname: "꩜⃟⃟ᴅ ʏ 𝐗-DEV",
      author: "ʙʏ: ꩜⃟⃟ᴅ ʏ 𝐗- B O T Z 〆"
    },
   messages: {
      wait: "*( Loading )* Tunggu Sebentar...",
      owner: "*( Denied )* Kamu bukan owner ku !",
      premium: "*( Denied )* Fitur ini khusus user premium",
      group: "*( Denied )* Fitur ini khusus group",
      botAdmin: "*( Denied )* Lu siapa bukan Admin group",
      grootbotbup: "*( Denied )* Jadiin Yuta-Botz admin dulu baru bisa akses",
   },
   database: "hanako-db",
   tz: "Asia/Jakarta"
}

module.exports = config

let file = require.resolve(__filename);
fs.watchFile(file, () => {
   fs.unwatchFile(file);
  delete require.cache[file];
});
