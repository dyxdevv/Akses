require('../../config');
const axios = require("axios");

let handler = async (m, { Thezy, text }) => {
    if (!text) return m.reply("Masukkan teks untuk membuat stiker brat video.");

    try {
        let brat = `https://fgsi1-brat.hf.space/?text=${encodeURIComponent(text)}&isVideo=true`;
        let response = await axios.get(brat, { responseType: "arraybuffer" });

        let videoBuffer = response.data;
        if (!videoBuffer) throw new Error("Gagal mengambil video.");

        await Thezy.sendVideoAsSticker(m.chat, videoBuffer, m, {
            packname: "Stiker By",
            author: "Alifatah - Multi Device",
        });

        console.log("Stiker berhasil dibuat.");
    } catch (err) {
        console.error("Error:", err);
        m.reply("Terjadi kesalahan saat mencoba membuat stiker video. Silakan coba lagi.");
    }
};

deku.command = "bratvid"
deku.alias = []
deku.category = ["main"]
deku.settings = {
    limit: true
}
deku.description = "sticker bratvid"
deku.loading = true

module.exports = deku
