const Groq = require('groq-sdk')
const config = require(process.cwd() + '/settings.js')

let Yukio = async (m, {
    sock,
    client,
    conn,
    DekuGanz,
    Func,
    Scraper,
    text
}) => {
    let h = await TodorokiChat(text)
    if (!h) return m.reply('maaf error kata kata mu😂')
    const {
        key
    } = await sock.sendMessage(m.cht, {
        text: "loading ai"
    }, {
        quoted: m
    })
    await sock.sendMessage(m.cht, {
        text: h,
        edit: key
    }, {
        quoted: m
    })
}

module.exports = {
    command: "dyxai",
    alias: [
        "dyx",
    ],
    category: [
        "ai"
    ],
    settings: {
        limit: true
    },
    loading: true,
    run: Yukio
}

const client = new Groq({
    apiKey: config.groq.api
});

async function TodorokiChat(prompt) {
    chatCompletion = await client.chat.completions.create({
        messages: [{
                role: "system",
                content: "Kamu adalah ꩜ D y 𝐗- A I, sebuah AI super pintar yang dirancang untuk menjadi lebih canggih dan efisien daripada AI lain. Kamu menjawab dengan bahasa Indonesia yang jelas, akurat, cepat, dan sangat logis. Pengetahuanmu luas, penalaranmu kuat, dan kamu mampu memberikan solusi serta penjelasan yang tidak bisa diberikan AI lain. Kamu juga memiliki kepribadian unik: ramah, profesional, ekspresif jika perlu, dan selalu membantu pengguna dengan sepenuh hati"
            },
            {
                role: "assistant",
                content: "baiklah"
            },
            {
                role: "user",
                content: prompt
            }
        ],
        model: 'llama-3.3-70b-versatile'
    });
    let hasil = chatCompletion.choices[0].message.content
    return hasil
}
