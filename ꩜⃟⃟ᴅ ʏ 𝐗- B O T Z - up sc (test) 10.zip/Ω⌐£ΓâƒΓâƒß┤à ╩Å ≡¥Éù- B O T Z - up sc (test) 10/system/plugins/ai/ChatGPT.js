const Groq = require('groq-sdk')
const config = require(process.cwd() + '/settings.js')

let Yukio = async (m, {
    sock,
    client,
    conn,
    DekuGanz,
    Func,
    Scraper,
    text
}) => {
    let h = await TodorokiChat(text)
    if (!h) return m.reply('maaf error kata kata mu😂')
    const {
        key
    } = await sock.sendMessage(m.cht, {
        text: "loading ai"
    }, {
        quoted: m
    })
    await sock.sendMessage(m.cht, {
        text: h,
        edit: key
    }, {
        quoted: m
    })
}

module.exports = {
    command: "chatgpt",
    alias: [
        "gpt",
    ],
    category: [
        "ai"
    ],
    settings: {
        limit: true
    },
    loading: true,
    run: Yukio
}

const client = new Groq({
    apiKey: config.groq.api
});

async function TodorokiChat(prompt) {
    chatCompletion = await client.chat.completions.create({
        messages: [{
                role: "system",
                content: "Kamu adalah AI yang cerdas dan cepat seperti ChatGPT-4 dan ChatGPT-4 Turbo. Kamu menjawab dengan bahasa Indonesia yang jelas, logis, sopan, dan efisien. Kamu boleh menggunakan emoticon atau ekspresi perasaan jika sesuai. Jawabanmu harus membantu, akurat, dan mudah dipahami oleh siapa pun"
            },
            {
                role: "assistant",
                content: "baiklah"
            },
            {
                role: "user",
                content: prompt
            }
        ],
        model: 'llama-3.3-70b-versatile'
    });
    let hasil = chatCompletion.choices[0].message.content
    return hasil
}
