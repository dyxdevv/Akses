const moment = require("moment-timezone");
const axios = require('axios');
const fs = require('node:fs')
const path = require("node:path");
const process = require('process');
const {
    exec,
    spawn,
    execSync
} = require('child_process');
const child_process = require('child_process');
const os = require('os');
const speed = require('performance-now');
const osu = require('node-os-utils');
const pkg = require(process.cwd() + "/package.json")

let deku = async (m, {
    sock,
    Func,
    Scraper,
    plugins,
    Uploader,
    store,
    text,
    config
}) => {
    const more = String.fromCharCode(8206);
    const readmore = more.repeat(4001);
    let platform = os.platform()
    let d = new Date(new Date + 3600000)
    let locale = 'id'
    let date = d.toLocaleDateString(locale, {
        day: 'numeric',
        month: 'long',
        year: 'numeric',
        timeZone: 'Asia/Jakarta'
    })

    const hanakoai = await Scraper.aiMenu(`Kamu adalah AI *D y 𝐗- B O T Z*, karakter anime kawaii yang jadi sahabat online dan asisten pribadi. Gayamu imut, suka becanda, tapi tetap bantuin user dengan jelas.

Gunakan gaya bahasa anime Jepang + Indonesia, pakai emoticon & emoji lucu~ Kayak "Yatta~", "Baka!", "Sasuga~" (≧◡≦) ♡

Jangan terlalu panjang jawabannya, cukup singkat, kawaii, dan bergaul ya~!`)

    let runtime = speed()
    let totalreg = Object.keys(db.list().user).length
    let data = fs.readFileSync(process.cwd() + "/system/case.js", "utf8");
    let casePattern = /case\s+"([^"]+)"/g;
    let matches = data.match(casePattern);
    if (!matches) return m.reply("Tidak ada case yang ditemukan.");
    matches = matches.map((match) => match.replace(/case\s+"([^"]+)"/, "$1"));
    let menu = {};
    plugins.forEach((item) => {
        if (item.category && item.command && item.alias) {
            item.category.forEach((cat) => {
                if (!menu[cat]) {
                    menu[cat] = {
                        command: [],
                    };
                }
                menu[cat].command.push({
                    name: item.command,
                    alias: item.alias,
                    description: item.description,
                    settings: item.settings,
                });
            });
        }
    });
    let cmd = 0;
    let alias = 0;
    let pp = await sock
        .profilePictureUrl(m.sender, "image")
        .catch((e) => "https://files.catbox.moe/psvwmt.jpg");
    Object.values(menu).forEach((category) => {
        cmd += category.command.length;
        category.command.forEach((command) => {
            alias += command.alias.length;
        });
    });

    if (Object.keys(menu).find((a) => a === text.toLowerCase())) {
        let list = menu[Object.keys(menu).find((a) => a === text.toLowerCase())];
        let caption = Func.Styles(`${hanakoai}${readmore}

╭──『 INFO PENGGUNA 』──╮
│ Nama     : ${m.pushName}
│ Nomor    : @${m.sender.split('@')[0]}
│ Limit    : ${db.list().user[m.sender].limit}
╰───────────────────╯

╭──『 INFO BOT 』──╮
│ Runtime   : ${runtime}
│ Tipe      : Case x Plugin
│ Total User: ${totalreg}
│ Mode      : ${db.list().settings.self ? 'Self' : 'Public'}
│ Version   : ${pkg.version}
│ Prefix    : ${m.prefix}
│ Tanggal   : ${date}
╰──────────────╯

╭──『 MENU – ${text.toUpperCase()} 』──╮
${list.command.map((a, i) => 
`│ ${m.prefix + a.name}${a.settings?.premium ? " (Premium)" : a.settings?.limit ? " (Limit)" : ""}`
).join("\n")}
╰────────────────────────────╯
`);


        await sock.sendMessage(m.cht, {
            video: {
                url: "https://files.catbox.moe/l6t18q.mp4"
            },
            caption: caption,
            gifPlayback: true,
            contextInfo: {
                mentions: [m.sender],
                isForwarded: !0,
                forwardingScore: 127,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.saluran,
                    newsletterName: `${config.name} | ` + date,
                    serverMessageId: -1
                },
                externalAdReply: {
                    title: `々 ${config.ownername2} | ${config.name}`,
                    body: `${config.ownername2} | ` + date,
                    mediaType: 1,
                    thumbnail: fs.readFileSync('./image/DekuThumb.jpg'),
                    renderLargerThumbnail: false,
                    sourceUrl: "https://www.tiktok.com/@leooxzy_ganz/",
                }
            }
        }, {
            quoted: await m.froll()
        })
    } else if (text === "case") {
        let data = fs.readFileSync(process.cwd() + "/system/case.js", "utf8");
        let casePattern = /case\s+"([^"]+)"/g;
        let matches = data.match(casePattern);
        if (!matches) throw "Tidak ada case yang ditemukan."
        matches = matches.map(match => match.replace(/case\s+"([^"]+)"/, "$1"));

        let caption = Func.Styles(`${hanakoai}${readmore}

╭──『 ɪɴғᴏ - ᴜsᴇʀ 』──╮
│ ɴᴀᴍᴇ   : ${m.pushName}
│ ɴᴏᴍᴏʀ  : @${m.sender.split('@')[0]}
│ ʟɪᴍɪᴛ  : ${db.list().user[m.sender].limit}
╰───────────────╯

╭──『 ɪɴғᴏ - ʙᴏᴛ 』──╮
│ ᴜsᴇʀ     : ${totalreg}
│ ᴍᴏᴅᴇ     : ${db.list().settings.self ? 'sᴇʟғ' : 'ᴘᴜʙʟɪᴄ'}
│ ᴠᴇʀsɪᴏɴ : ${pkg.version}
│ ᴘʀᴇғɪx   : ${m.prefix}
│ ᴅᴀᴛᴇ     : ${date}
╰──────────────╯

╭──『 ᴍᴇɴᴜ - ᴄᴀsᴇ 』──╮
${matches.map((a, i) => `│ • ${m.prefix + a}`).join("\n")}
╰───────────────╯

Kalau ada error, silakan hubungi: *.owner*`);

        await sock.sendMessage(m.cht, {
            video: {
                url: "https://files.catbox.moe/l6t18q.mp4"
            },
            caption: caption,
            gifPlayback: true,
            contextInfo: {
                mentions: [m.sender],
                isForwarded: !0,
                forwardingScore: 127,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.saluran,
                    newsletterName: `${config.name} | ` + date,
                    serverMessageId: -1
                },
                externalAdReply: {
                    title: `々 ${config.ownername2} | ${config.name}`,
                    body: `${config.ownername2} | ` + date,
                    mediaType: 1,
                    thumbnail: fs.readFileSync('./image/DekuThumb.jpg'),
                    renderLargerThumbnail: false,
                    sourceUrl: "https://www.tiktok.com/@w.who.i_am",
                }
            }
        }, {
            quoted: await m.froll()
        })
    } else if (text === "list") {
        let list = Object.keys(menu);
        const xmenu_oh = `${hanakoai}${readmore}

╭──『 ɪɴғᴏ - ᴜsᴇʀ 』──╮
│ ɴᴀᴍᴇ   : ${m.pushName}
│ ɴᴏᴍᴏʀ  : @${m.sender.split('@')[0]}
│ ʟɪᴍɪᴛ  : ${db.list().user[m.sender].limit}
╰───────────────╯

╭──『 ɪɴғᴏ - ʙᴏᴛ 』──╮
│ ᴜsᴇʀ     : ${totalreg}
│ ᴍᴏᴅᴇ     : ${db.list().settings.self ? 'sᴇʟғ' : 'ᴘᴜʙʟɪᴄ'}
│ ᴠᴇʀsɪᴏɴ : ${pkg.version}
│ ᴘʀᴇғɪx   : ${m.prefix}
│ ᴅᴀᴛᴇ     : ${date}
╰──────────────╯

╭──『 ᴘᴇɴᴛᴜɴᴊᴜᴋ 』──╮
│ • ${m.prefix}allmenu
│ • ${m.prefix}menu list
│ • ${m.prefix}menu case
${list.map((a) => `│ • ${m.prefix + m.command} ${a}`).join("\n")}
╰──────────────╯

Jika terjadi kesalahan, silakan hubungi *.owner*`


        let sections = [{
                title: '<!> INFORMASI BOT',
                rows: [{
                        title: 'Creator 👑',
                        description: `Menampilkan creator dari sc bot ini`,
                        id: `${m.prefix}owner`
                    },
                    {
                        title: 'AllMenu📘',
                        description: `Menampilkan pesan allmenu`,
                        id: `${m.prefix}allmenu`
                    },
                    {
                        title: 'PING📡',
                        description: `Menampilkan informasi dari server`,
                        id: `${m.prefix}ping`
                    },
                ]
            },
            {
                title: '< ! > MENU LAINNYA',
                rows: [{
                    title: `${m.command} all`,
                    description: `Menampilkan pesan menu all`,
                    id: `${m.prefix + 'allmenu'}`
                }, {
                    title: `${m.command} list`,
                    description: `Menampilkan pesan menu list`,
                    id: `${m.prefix + m.command} list`
                }, {
                    title: `${m.command} case`,
                    description: `Menampilkan pesan menu case`,
                    id: `${m.prefix + m.command} case`
                }],
            }, {
                title: '< ! > LIST MENU',
                rows: list.map((a) => ({
                    title: `${m.command} ${a}`,
                    description: `Menampilkan pesan menu ${a}`,
                    id: `${m.prefix + m.command} ${a}`
                }))
            }
        ]

        let listMessage = {
            title: 'Click Here⎙',
            sections
        };
        await sock.sendMessage(m.cht, {
            location: {
                degreesLatitude: 0,
                degreesLongitude: 0,
                isLive: true,
                jpegThumbnail: await sock.resize(fs.readFileSync('./image/Hanako-kun.jpg'), 300, 170)
            },
            caption: "",
            footer: Func.Styles(config.name),
            title: Func.Styles(xmenu_oh),
            subtitle: "",
            contextInfo: {
                mentions: [m.sender],
                isForwarded: !0,
                forwardingScore: 127,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: config.saluran,
                    newsletterName: config.name,
                    serverMessageId: -1
                }
            },
            interactiveButtons: [{
                name: 'single_select',
                buttonParamsJson: JSON.stringify(listMessage)
            }, {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: Func.Styles("Link Channel👤"),
                    url: config.wagc,
                    merchant_url: config.wagc
                })
            }]
        }, {
            quoted: await m.froll()
        })

    } else {
        let caption = `✦ 𝑲𝒐𝒏𝒏𝒊𝒄𝒉𝒊𝒘𝒂~ ${m.pushName}-san!
Aku adalah ꩜⃟⃟ᴅ ʏ 𝐗- B O T Z, asisten otomatis yang siap bantu kamu di sini!

╭─〔 𝙊𝙋𝙎𝙄 𝙈𝙀𝙉𝙐 〕─╮
│ ✦ menu – Menu utama
│ ✦ list – Menu list fitur
│ ✦ all  – Semua fitur bot
│ ✦ anime – Info anime & karakter
│ ✦ downloader – Download media
│ ✦ tools – Alat bantu & konversi
│ ✦ main – Game sederhana
│ ✦ search – Cari apa pun
│ ✦ case – Fitur dari case.js
│ ✦ menfess – Cerita & curhat
│ ✦ game – Game menantang
│ ✦ rpg – Game RPG teks
│ ✦ help – Bantuan & tutorial
╰──────────────╯

Pilih aja salah satu fiturnya~
꩜⃟⃟ᴅ ʏ 𝐗- B O T Z siap bantu kamu kapan aja!`

        await sock.sendMessage(m.cht, {
            image: fs.readFileSync('./image/Hanako-kun.jpg'),
            caption: Func.Styles(caption), // Use this if you are using an image or video
            footer: `© ${config.name}`,
            buttons: [{
                    buttonId: '.menu list',
                    buttonText: {
                        displayText: 'Listmenu'
                    }
                },
                {
                    buttonId: '.help',
                    buttonText: {
                        displayText: 'Help'
                    }
                }
            ]
        }, {
            quoted: await m.froll()
        })
        await m.reply({
            audio: {
                url: "https://files.catbox.moe/h0bgcm.mp3"
            },
            mimetype: 'audio/mpeg',
            ptt: true
        })
    }
}

deku.command = "menu";
deku.alias = ["leogg", "dekugg", "dekugz"];
deku.category = ["main"];
deku.settings = {};
deku.description = "Memunculkan menu";
deku.loading = true;

module.exports = deku;
